export const TRAER_TODOS = 'publicaciones_traer_todos';
export const CARGANDO = 'publicaciones_cargando';
export const ERROR = 'publicaciones_error';