export const CARGANDO = 'publicaciones_cargando';
export const ERROR = 'publicaciones_error';
export const ACTUALIZAR = 'publicaciones_actualizar';