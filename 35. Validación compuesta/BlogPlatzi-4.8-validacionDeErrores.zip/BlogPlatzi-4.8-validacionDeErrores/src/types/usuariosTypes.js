export const TRAER_TODOS = 'usuarios_traer_todos';
export const CARGANDO = 'usuarios_cargando';
export const ERROR = 'usuarios_error';