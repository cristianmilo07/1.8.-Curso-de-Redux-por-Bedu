export const CARGANDO = 'publicaciones_cargando';
export const ERROR = 'publicaciones_error';
export const TRAER_POR_USUARIO = 'publicaciones_traer_por_usuario';