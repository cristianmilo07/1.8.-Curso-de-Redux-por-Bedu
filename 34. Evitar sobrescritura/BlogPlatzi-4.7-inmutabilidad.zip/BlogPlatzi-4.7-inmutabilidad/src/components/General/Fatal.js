import React from 'react';

const Fatal = (props) => (
	<h2 className='center rojo'>
		{ props.mensaje }
	</h2>
);

export default Fatal;